$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== ""){
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top - 40
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
})


// shake $( document ).click(function() {
// define global vars
const sections = document.querySelectorAll('.udacity');
const nav_links= document.querySelectorAll('a.nav-link');
const second_back = document.querySelector('#second_back_btn');
const main_back_btn = document.querySelector('#main_back_btn');



function remover() {
     sections.forEach( (elm)=> { 
        elm.classList.remove("udacity_active");
});

     
}


        function link_removers(){
        nav_links.forEach( (link_edit)=> { 
           link_edit.classList.remove("udacity_active_link");
        });
        }

function myscroll() {



function x() {
$("#shaked_flower").effect( "shake", {times:2}, 1500 );
}

sections.forEach( (section)=> { 
  //alert(section.id);
  let rect = section.getBoundingClientRect();
  let top = rect.top;
  let bottom = rect.bottm;
  let hight = rect.height;
  let avg = hight - window.innerHeight;
  if(!$(window).scrollTop()) { 
  //abuse 0 == false :)
    remover();
    link_removers();

     x();
  }
  if (top > 0 && rect.bottom < window.innerHeight + avg + 50) {
  

     remover();
     section.classList.add("udacity_active");
     // show the second back to top btn     
     second_back.style.display = "block";
     
     // hide the main back btn
     main_back_btn.style.visibility = "hidden";
     let active_section = section;
     
     function checklink(active_section) {
     nav_links.forEach( (link)=> { 
        let section_id = link.getAttribute('data-nav');
        if ( active_section.id == section_id) {
        
        // remove old classess
        

        link_removers();
          // give the active link active class
          link.classList.add("udacity_active_link");

        }
     });
     }
     checklink(active_section);
     
  } 
})

}
window.addEventListener('scroll', myscroll);



$(window).scroll(function() {
    clearTimeout($.data(this, 'scrollTimer'));
    $.data(this, 'scrollTimer', setTimeout(function() {
        // do something
       remover();
       link_removers();
       second_back.style.display = "none";
    }, 3000));
});

// check if user scrolled to the bottom
// remove links class
$(window).scroll(function() {
   if($(window).scrollTop() + $(window).height() == $(document).height()) {
   
      remover();
      link_removers();
      second_back.style.display = "none";
      main_back_btn.style.visibility = "visible";

   }
});

// back to top smoth scroll action and hide + hide nav

let navs = document.querySelector('#second_btn_back_span');
second_back.addEventListener('click', (event)=> {
  event.preventDefault();
        navs.style.display = "block";
        navs.scrollIntoView({behavior: "smooth"});
        navs.style.display = "none";
});





/* login and sign up buttons function */
/* hide nav and show it on click on models added by onclick */

const topnav = document.getElementById("mytopnav");

function hide_nav() {
  topnav.style.visibility = "hidden"
}

function show_nav() {
  topnav.style.visibility = "visible"
}

// this to help model help bootstrap4 when close model on click out side not only cancel button 
window.addEventListener('click', show_nav1);
function show_nav1(event) {
  let get_target = event.target;
  let target_class = String(get_target.className);
  
  //let first_part = target_class.slice(0, 5)
  if (target_class == 'modal fade sign_style') {
      show_nav();
  }
}

/* smooth scroll to the buy it section */


	  const offer_buy_btn = document.getElementById("buy_btn_offer");
	  const join_us_section = document.getElementById("join_us");
	  offer_buy_btn	.addEventListener('click', (event)=> { 
	     join_us_section.scrollIntoView({behavior: "smooth"});
	  });

	  
/* Search Friends Function */ 

function search_friends() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}	  