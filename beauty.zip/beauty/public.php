<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is  logged in redirect to the Not Public index...
if (isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <title>Public Beauty DEMY</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">









  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="static/style.css" rel="stylesheet" type="text/css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <style>

  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<span style="display:none;margin:0;" id="second_btn_back_span" ></span>
<nav class="navbar navbar-expand-md bg-sucess navbar-dark fixed-top" id="mytopnav">
  <a class="navbar-brand" href="/"><img src="static/logo_transparent.png" width="50" height="50" alt="beauty demy logo"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" data-nav='beauty_comunity' href="#beauty_comunity" title="Beauty Community for Premium Beauty Demy Memeber">BEAUTY Community</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-nav='services' href="#services" title="check Membership Features">FEATURES</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-nav='pricing' href="#pricing" title="Become A Premium Memeber Buy the Course">JOIN DEMY</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="#contact" data-nav='contact' title="Contact Us Channel We would love to answer your inquiries">CONTACT</a>
      </li>
    </ul>
  </div>
</nav>


<div class="jumbotron text-center">
  <h1><kbd style="color:white;opacity:0.6;">Beauty Demy</kbd></h1>
  <p><kbd style="background-color:#ffbfe4;color:black;opacity:0.9;"><strong>Professional Makeup Courses</strong></kbd></p>
  <form class="form-inline">
    <div class="container" style="margin-left:auto;margin-right:auto;">
        <button type="button" class="btn btn-danger sp_warp_btn change_in_mobile" >Register</button>
        <a href="login.php"><button type="button" class="btn btn-info sp_warp_btn change_in_mobile" style='margin-left:5px;margin-top:3px;'>LOGIN</button></a>
    </div>
  </form>

  <br><br><br>
  <img id="shaked_flower" src="static/flowers.png"
  width="200" height="100" alt="small image contains Bouquet of flowers">
</div>

<!-- Container (About Section) -->
<div id="classroom" class="container-fluid udacity">
  <div class="row">
    <div class="col-sm-7">
      <h2>how to be a professional  make up Artist</h2><br>


<h4>About this course</h4>
      <p>What You Need to Know To Be a Professional Makeup Artist.</p><br>

    <h4>Description</h4>
      <p>Beauty by Bethany - Professional is an online course that will teach you what you need to know to be a professional make up artist.
      This extensive course includes:</p>

<button class="btn btn-info btn-lg" data-toggle="modal" data-target="#ju_course_info" onclick="hide_nav()">See More</button>

       <!-- course deatlis
  <div id="demo" class="collapse">

<div class="container">
  <h4 class="text-center">Course Details</h4>
  <div class="list-group ">
    <a href="#" class="list-group-item list-group-item-success">Skill level: All Levels</a>

    <a  class="list-group-item">Students: <span>160?</span></a>
    <a  class="list-group-item list-group-item-success">Lectures: 66</a>
    <a  class="list-group-item">Languages: English</a>
    <a  class="list-group-item">Captions: Yes</a>
    <a  class="list-group-item active">Video: 25 total hours</a>

  </div>
</div>

  </div>

      -->


    </div>
    <div class="col-sm-5">


          <video width="100%" height="400" controls>
		  <!--
  <source src="movie.mp4" type="video/mp4">
  <source src="movie.ogg" type="video/ogg">

  -->
Your browser does not support the video tag.
</video>



    </div>
  </div>
</div>

<div id='beauty_comunity' class="container-fluid bg-grey udacity">
  <div class="row">
    <div class="col-sm-4">
      <div class="thumbnail">


 <div class='text-center'>




                     <div class="box4">
                        <img src="static/commnuity_1.jpg" alt="img contains some alot of makeup tools">
                        <div class="box-content">
                            <div class="inner-content">
                                <h3 class="title">Beauty News</h3>
                                <span class="post">Kepp Updated</span>

                            </div>
                        </div>
                    </div>







Select Your Brand Easy</div>
            </div>

      <div class='text-center thumbnail'>                      <div class="box4">
                        <img src="static/commnuity_2.jpg" alt="woman add makeup in her face with green and alot of colors">
                        <div class="box-content">
                            <div class="inner-content">
                                <h3 class="title">Beauty Community</h3>
                                <span class="post">Don't Wait Join</span>

                            </div>
                        </div>
                    </div>

      Get FeedBack We Need it
  </div>

    </div>
    <div class="col-sm-8 ">
      <h2>Beauty Community</h2><br>
      <h4><strong>Enjoy:</strong> Our Community Best Beauty Community ever, chat with other users Learn, Create Posts And Communicate with other Makeup Artists .</h4><br>
      <p><strong>We Can Help You To Select Ideal Makeup For you:</strong><br><br> Upload your new makeup test images to the community and get / in real time from our active users and your friends, it is always important to check other people's comments especially in makeup</p>
      <br><br>
      <div style="text-align:center;">
      <button class='btn btn-info' id="buy_btn_offer" >Buy The Membership only $12</button>



      </div>
    </div>
  </div>
</div>

<!-- Container (Services Section) -->
<div id="services" class="container-fluid text-center udacity">
  <h2>Become A Premium</h2>
  <h4>What we offer for our Premuium Memebers</h4>
  <br>
  <div class="row">
    <div class="col-sm-4 ">
      <span class="fas fa-book logo-small zoom1"></span>
      <br><br>
      <h4>ClassRoom Acess</h4>
      <p>Acess To Beauty Demy CLASSROOM.</p>
    </div>
    <div class="col-sm-4">
      <span class="fas fa-heart	 logo-small zoom1"></span>
      <br><br>
      <h4>Beauty Demy Couminty</h4>
      <p>Access To Beauty Demy Couminty..</p>
    </div>
    <div class="col-sm-4">
      <span class="fas fa-signal logo-small zoom1"></span>
      <br><br>
      <h4>Beauty Demy News</h4>

      <p>Access To Beauty Demy News..</p>
    </div>
  </div>
  <br><br>
  <div class="row">
    <div class="col-sm-4">
      <span class="fas fa-leaf logo-small zoom1"></span>
      <br><br>
      <h4>Gift Center</h4>
      <p>You Can Gift the Course to anyone..</p>
    </div>
    <div class="col-sm-4">
      <span class="fas fa-certificate logo-small zoom1"></span>
       <br><br>
      <h4>CERTIFIED</h4>
      <p>Receive a Certification of completion..</p>
    </div>
    <div class="col-sm-4">
      <span class="fas fa-support logo-small zoom1"></span>
      <br><br>
      <h4 style="color:#303030;">Customer Support</h4>
      <p>Premium Support Team Will Ready To Help ..</p>
    </div>
  </div>
</div>





<!-- Container (Pricing Section) -->



<div id="pricing" class="container-fluid udacity">
  <div class="text-center" style="color:white;" id="join_us">
    <h2 style="color:#000;">Let's Do IT</h2>
    <h4 style="color:#000;">You Will Become Professional Makeup Artist After This Course</h4>
  </div>
  <div class="row">
    <div class="container">
      <div class="panel panel-default text-center card bg-primary" style="border:1px solid gold;">
<div class="card">
  <img src="static/proudct_image.jpg" alt="John" style="width:100%" alt="image for woman eye put makeup on her eye and she clossed her eyes" >

  <h2 style='font-family: lemon;font-size:16px;color:white;background-color:pink;padding:10px;width:80%;text-align:center;margin-left:auto;margin-right:auto;'>HOW TO BE A PROFESSIONAL MAKE UP ARTIST</h2>

<p style='color:black;'>What You Need to Know To Be a Professional Makeup Artist
<br><kbd style="color:pink;">Professional Makeup Course</kbd></p>

<hr>

<h4 > <strong>High Rated Course</strong></h4>
<p>
<i class="fas fa-star" style='color:gold;font-size:25px;'></i>
<i class="fas fa-star" style='color:gold;font-size:25px;'></i>
<i class="fas fa-star" style='color:gold;font-size:25px;'></i>
<i class="fas fa-star" style='color:gold;font-size:25px;'></i>
<i class="fas fa-star" style='color:gold;font-size:25px;'></i>
</p>

  <p style="padding:10px;font-size:20px;font-family:sans;"><kbd style="background-color:pink;"><strong>Price $12</strong></kbd></p>
  <hr>
  <div>
<button class='btn btn-success' style="padding:10px;width:40%;">Buy Now!</button>
<button class='btn btn-info' style="padding:10px;width:40%;" data-toggle="modal" data-target="#ju_course_info" onclick="hide_nav()">Course Info</button>

</div>
<br><br>
</div>
      </div>
    </div>

  </div>
</div>



<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey udacity">
  <h2 class="text-center">CONTACT US</h2>
  <p class="text-center">We Always Here To Help</p>
  <div class="row">
    <div class="col-sm-5">

      <p><span class="fas fa-marker"></span> Saudi Arabia</p>
      <p><span class="fas fa-envelope"></span> myemail@something.com</p>
    </div>
    <div class="col-sm-7">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Your Name Please" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Your Email For Contact" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Add Your Message Here Please." rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-primary pull-right" type="submit">Send</button>
          <br><br>
          <p>Contact us and we'll get back to you within 24 hours.</p>
		  <p><kbd>Your Support Is Our Goal</kbd></p>
		  <br /><br /><br />
        </div>
      </div>
    </div>
  </div>
</div>


<a id="second_back_btn" href="" title="To Top" style="display:none;text-align:center;">
    <span class="fas fa-arrow-up zoom2 logo-small" style="font-size:20px;color: pink;"></span>
    <br>
    <span class="fas fa-heart logo-small zoom2" style='color:pink;'></span>
  </a>


<!-- Image of location/map
<img src="/w3images/map.jpg" class="w3-image w3-greyscale-min" style="width:100%">
 -->

<footer class="container-fluid text-center bg_foot" id="foot" style="color:white;opcaity:0.8;">
  <a id="main_back_btn" href="#myPage" title="To Top" style="visibility:hidden">
    <span class="fas fa-arrow-up zoom2 logo-small" style="font-size:20px;"></span>
    <br>
    <span class="fas fa-heart logo-small zoom2" style="font-size:30px;"></span>
  </a>

  <p style="margin-right:20px;color:black;"> Follow us on:<a href="https://www.w3schools.com" title="We Need Your Support On Instagram! Just 1 Click Follow US T" style="color:black;font-family:times;text-decoration:none;font-size:18px">


<i class="fa fa-instagram" style="font-size:48px;color:tomato;margin-left:5px;margin-right:5px;"></i>

  Instgram</a></p>
</footer>



<!-- login and sign up models start -->

  <!-- The Modal -->
  <div class="modal fade sign_style" id="signup">
    <div class="modal-dialog modal-xl">
      <div class="modal-content sign_content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Join Beauty Demy</h4>
          <button type="button" class="close" data-dismiss="modal" onclick="show_nav()">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">

          <!-- login form -->
          <div class="container form_container">
            <h2 class="text-center" style=""><strong>Create New Account</strong></h2>
            <br />
            <p></p>
            <form action="/action_page.php" class="was-validated">
            <div class="form-group">
            <label for="uname"><b>Username: </b></label>
            <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" required>
            <div class="valid-feedback">Valid.</div>
            <div class="invalid-feedback">Please fill out this field.</div>
            </div>
           <div class="form-group">
            <label for="pwd"><b>Password:</b></label>
            <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required>
          <div class="valid-feedback">Valid.</div>
        <div class="invalid-feedback">Please fill out this field.</div>
      </div>
           <div class="form-group">
            <label for="pwd">Confirm Password:</label>
            <input type="password" class="form-control" id="cpwd" placeholder="Confirm password" name="cpswd" required>
          <div class="valid-feedback">Valid.</div>
        <div class="invalid-feedback">Please fill out this field.</div>
      </div>

	<div class="form-group">
	       <label for="sign_mail">Email:</label>
          <input class="form-control" id="sign_mail" name="sign_mail" placeholder="Please Enter Your Mail" type="email" required>
		  <div class="valid-feedback">Valid.</div>
		  <div class="invalid-feedback">Please Enter Valid Email Address.</div>
        </div>
       <div class="form-group">

            <label for="uname"><strong>Gender:</strong></label>
            <div>
            <input type="radio"  id="female"  name="gender" >
            <label for="female"><strong>Female</strong></label>
            <input type="radio"  id="male"    name="gender" >
            <label for="male"><strong>Male</strong> </label>
             </div>
            </div>
      <div class="form-group">
          <label for="uname"><b>Full Name: </b></label>
          <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" required>
          <div class="valid-feedback">Valid.</div>
          <div class="invalid-feedback">Please fill out this field.</div>
     </div>

    <div class="form-group">
          <label for="photo"><b>Your Photo: </b></label>
          <input type="file" class="form-control" id="photo"  name="photo" style="border:none;background-color:transparent;">
     </div>


     <div class="container" style="margin-left:10px;">
             <input class="form-check-input" type="checkbox" name="remember" required> I agree on
               <a  data-toggle="collapse" data-target="#demo" style="cursor:pointer;"><kbd style="background-color:pink;color:black;">Terms & Conditions</kbd></a>
              </div>

              <br>
              <div class="modal-footer">
              <input class="btn btn-success" type="submit" name="submit" value="Submit">
               <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="show_nav()">Cancel</button>
              </div>


        </form>




          <span>


  <br /><br />

     <!-- start of terms and conditions -->
  <div id="demo" class="collapse">
<div class="container">


  <!-- The Modal -->
  <div class="container" id="myModal">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h5 class="modal-title" style="font-size:1em">Terms & Conditions</h5>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <h3 style="font-size:1em">Some text to enable scrolling..</h3>
          <p>Some text to enable scrolling.. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
          <p>Some text to enable scrolling.. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

          <p>Some text to enable scrolling.. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer" >
          <p style="margin-right:24%;font-size:1em;font-family:Times,"><b>Thank You for Joining US</b></p>
        </div>

      </div>
    </div>
  </div>


  </div>
 <!-- end of serivces and agreemnt model-->

  </div>
</span>
          <!-- end services and agremnts container -->






      </div>
    </div>
  </div>
  <!-- end -->
</div>
</div>


<!-- sign up model end -->

  <!-- Button to Open the Modal -->


<!-- login model start------------------------------------------------------------ -->



    <!-- login and sign up models end -->



  <!-- Course info Modal Start-->
  <div class="modal fade sign_style" id="ju_course_info"  data-nav="the_card">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">

        <!-- Course info Modal Header -->
        <div class="modal-header">
          <h6 class="modal-title">How To Be a Professional Make Up Artist</h6>
          <button type="button" class="close" data-dismiss="modal" onclick="show_nav()">×</button>
        </div>





        <!-- Course info Modal body -->
        <div class="modal-body">
          <h3>About this course:</h3>
          <p>What You Need to Know To Be a Professional Makeup Artist</p>

          <h3>By the numbers: </h3>


            <ul class="list-group">

            <li class="list-group-item">Skill level: All Levels</li>
            <li class="list-group-item"> Lectures: 66</li>
            <li class="list-group-item">Students: 160 </li>
            <li class="list-group-item"> Video: 25 total hours</li>
            <li class="list-group-item">Languages: English</li>
            <li class="list-group-item">Captions: Yes</li>
          </ul>

          <br />

         <br />

          <h3>Description</h3>
          <p>Beauty by Bethany - Professional is an online course that will teach you what you need to know to be a professional make up artist. This extensive course includes: <kbd data-toggle="collapse" data-target="#course_more">See More</kbd></p>


<div id="course_more" class="collapse">
            <ul class="list-group">

<li class="list-group-item active">Make Up Artistry</li>

<li class="list-group-item">Course 1 - Beauty Brushes (67:55)</li>
<li class="list-group-item">Course 2 - Your Makeup Kit (46:10)</li>
<li class="list-group-item">Course 3 - Etiquette On Set (36:18)</li>
<li class="list-group-item">Course 4 - How to Use Color Correctors (11:20)</li>
<li class="list-group-item">Course 5 - Film &#38; Television Makeup Artistry (54:14)</li>
<li class="list-group-item">Course 6 - Tattoo Covering (26:34)</li>
<li class="list-group-item">Course 7 - Tips On Natural Beauty Makeup (5:06)</li>
<li class="list-group-item">Course 8 - Tips On Glamour Makeup (57:02)</li>
<li class="list-group-item">Course 9 - How To Tips for Teenage Makeup (67:56)</li>
<li class="list-group-item">Course 10 - Makeup Tips for Sophisticated Ladies (28:12)</li>
<li class="list-group-item">Course 11 - Airbrush Makeup (26:22)</li>
<li class="list-group-item">Course 12 - Bridal Makeup (60:16)</li>
<li class="list-group-item">Course 13 - Eyes and Lips (18:57)</li>
<li class="list-group-item">Course 14 - Be Camera Ready (72:12)</li>
<li class="list-group-item">Course 15 - Skin Nutrition (40:40)</li>
<li class="list-group-item">Course 16 - Detox Your Makeup Bag &#38; Travel Like a Boss (31:29)</li>
<li class="list-group-item">Course 17 - Henna Hair Color (5:25)</li>
<li class="list-group-item">Course 18 - What Does Bethany do to Stay Fresh (23:18)</li>
<li class="list-group-item">Course 19 - Fast Business Training (11:07)</li>

<br /><br />

<li class="list-group-item active">Skin Care</li>

<li class="list-group-item">Course 1 - Skin Care and Tanning (40:38)</li>
<li class="list-group-item">Course 2 - Facials (110:12)</li>
<li class="list-group-item">Course 3 - Hair Removal Options (43:23)</li>
<li class="list-group-item">Course 4 - Dermaplaning (23:27)</li>
<li class="list-group-item">Course 5 - Esthetician Tools (11:57)</li>
<li class="list-group-item">Course 6 - LED Light Therapy (21:22)</li>
<li class="list-group-item">Course 7 - Microneedling (37:02)</li>
<li class="list-group-item">Course 8 - Natural and Chemical Peels (22:53)</li>
<li class="list-group-item">Course 9 - Skincare Using Spices (16:16)</li>
<li class="list-group-item">Course 10 - Skin Disorder and Diseases (7:54)</li>
<li class="list-group-item">Course 11 - Sugaring (15:29)</li>
<li class="list-group-item">Course 12 - Tinting (29:48)</li>
<li class="list-group-item">Course 13 - How To Be and Get Camera Ready (60:55)</li>
<li class="list-group-item">Course 14 - Why No Microdermabrasion (8:13)</li>
<li class="list-group-item">Course 15 - Food Knowledge (13:20)</li>
<li class="list-group-item">Course 16 - Skincare Using Spices (10:37)</li>

<br /><br />

<li class="list-group-item active">Things To Know As a Beauty Professional</li>

<li class="list-group-item">Course 1- Aromatherapy and Essential Oils (28:33)</li>
<li class="list-group-item">Course 2- Detox Your Deodorant (10:55)</li>
<li class="list-group-item">Course 3 - Dry Brushing (6:53)</li>
<li class="list-group-item">Course 4 - Face Masks (7:07)</li>
<li class="list-group-item">Course 5 - Find Your Perfect Color (11:38)</li>
<li class="list-group-item">Course 6 - Go Earthing (4:48)</li>
<li class="list-group-item">Course 7- Good Morning Detox (6:50)</li>
<li class="list-group-item">Course 8- Hot Flashes (5:09)</li>
<li class="list-group-item">Course 9 - Luxury Spa Treatments at Home (9:41)</li>
<li class="list-group-item">Course 10 - How to Conceal and Correct Under Your Eyes (15:55)</li>
<li class="list-group-item">Course 11 - Make-Up Your Health Routine (16:54)</li>
<li class="list-group-item">Course 12- Oil Pulling- Natural Teeth Whitening (4:24)</li>
<li class="list-group-item">Course 13 - Tanning Beds or Spray Tanning (8:38)</li>
<li class="list-group-item">Course 13 - What's in Your Lipstick (11:31)</li>
<li class="list-group-item">Course 14 - What’s All the Fuss About LED Light Therapy (5:32)</li>

<br /><br />


<li class="list-group-item active">"But Wait, There's More!" - Image Consulting</li>

<li class="list-group-item">Course 0 - Introduction (3:14)</li>
<li class="list-group-item">Course 1 - Flip Your Style (19:56)</li>
<li class="list-group-item">Course 2 - Accessories for Guys (17:20)</li>
<li class="list-group-item">Course 3 - Do's and Don't's for Men (7:55)</li>
<li class="list-group-item">Course 4 - Fashion for the Average Man (3:49)</li>
<li class="list-group-item">Course 5 - How to Look Great in a Suit (9:55)</li>
<li class="list-group-item">Course 6 - How to Organize Your Closet (5:38)</li>
<li class="list-group-item">Course 7 - Where Can Men Shop (6:00)</li>
<li class="list-group-item">Course 8 - Body Types (24:05)</li>
<li class="list-group-item">Course 9 - Keys to Fashion (3:10)</li>
<li class="list-group-item">Course 10 - Staples (32:03)</li>
<li class="list-group-item">Course 11 - Tour of Fabrics (9:29)</li>
<li class="list-group-item">Course 12 - Wigs (25:13)</li>
<li class="list-group-item">Course 13 - Material World &#38; Where to Buy Fabrics (36:33)</li>
<li class="list-group-item">Course 14 - What Does Bethany do to Stay Fresh (23:19)</li>
          </ul>
  <br /><br />

  <h5>What you’ll learn</h5>
<ul>
<li>What You Need to Know To Be a Professional Makeup Artist</li>
</ul>

<h5 style="font-size:16px;">Are there any course requirements or prerequisites ?</h5>
<ul>
<li>The desire to learn how to be a professional make up artist</li>
</ul>

<h5>Who this course is for:</h5>
<ul>
<li>Anyone who wants to be a professional make up artist</li>
</ul>

<hr>
<br>
<h4>Instructor</h4>
<img src="static/bea.jpg" width="70" height="70" style="border:1px solid gray;
border-radius:50%;">
<span><b> Greg Coon</b></span>
<br /><br />
<p>
Greg Coon is the President of Eyecon Video Productions, a professional video and television production company. Scott Miller has been a successful Network Marketing expert for over two decades. He also has been a sports and news anchor for numerous television news stations.

Greg and Scott have worked together for over 25 years producing numerous videos for Network Marketing companies. They videos they have produced have been invaluable in the success of thousands of Network Marketing individuals.

</p>
</div>
<!-- end collapse -->

        </div>

        <!-- Course info Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="show_nav()">Close</button>
        </div>

      </div>
    </div>
  </div>
<!-- Course info Modal end -->

      <script type="text/javascript"    src = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"> </script>

<script type="text/javascript" src="static/script.js"></script>


<script>

</script>
</body>
</html>
