<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

include('db.php');

// get loged user info from database
$stmt = $con->prepare('SELECT password, email, paid, image FROM accounts WHERE id = ?');
// In this case we can use the account ID to get the account info.
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($password, $email, $paid, $image);
$stmt->fetch();
$stmt->close();

// Convert $paid from number to String
if ($paid !== 1) {
	header('Location: index.php');
  exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>

  <title>CLASSROOM</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link href="static/style.css" rel="stylesheet" type="text/css">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>




  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>



  <style>

  body {
        font-family: "Times New Roman", Times, serif ;
        padding: auto;
        margin: auto;
        background-color: #fff0fb
!important;
  }

  .main_content {

  }



  .card-link {
    color: lightgray !important;
  }

  .classroom_btn {
   background-color: #ff6699 !important;
 color: white !important;
  }
  .background_pinky {
    background-color: #e60073 !important;
  }
  .jumbotron {
    background-image: url('static/header_background.jpg');
    height: 400px;
	color: white;
  }

  .jumbotron h1 {
    font-family: 'New Times Roman', Times, serif;
	font-size: 5em;
  }

  .the_logo {
    border: 2px solid white !important;
	border-radius: 4px;
  }

  .bg_foot {
   background: linear-gradient(to top, #ffffcc 0%, #ffcc99 54%) !important;
   height: 200px;
  }
  .bookmark_icon {
   font-size:38px !important;
   margin-left:10% !important;
   color:#0e5fc8 !important;
   cursor:pointer !important;
  }
  .play_list_span {
    float:right;
    color:#ff6699;
  }
  </style>
</head>
<body>


<div class="jumbotron text-center" style="margin-bottom:0 ">
  <h1>Beauty Demy</h1>
  <h6> <kbd><strong>Professional Makeup Courses!</strong></kbd></h6>
</div>


<nav class="navbar navbar-expand-md bg-sucess navbar-dark fixed-top" id="mytopnav_classroom">
  <a class="navbar-brand" href="index.php"><img src="static/logo_transparent.png" width="50" height="50" alt="beauty demy logo"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" data-nav='classroom.php' href="#">MY CLASSROOM</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-nav='beauty_comunity' href="#beauty_comunity">BEAUTY Community</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="profile.php" data-nav='profile'>Profile</a>
      </li>
      <li class="nav-item">
       <a class="nav-link" href="logout.php"  title="Go To Your Profile Page" ><i class="fas fa-sign-out-alt"></i>Logout</a>
     </li>
    </ul>
  </div>
</nav>




<div class="main_content">

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
<div class="container">
  <div class="card">
    <div class="card-header bg-dark text-center" style="color:white;"><?=$_SESSION['name']?></div>

  </div>
</div>
    <div class="container">
   <img src="<?=$image?>" width="100%" height="250" style="border:1px solid white;">
   </div>

   <!-- user info -->




   <!-- user info end -->
     <!-- information -->
<div class="container">
  <div id="accordion">





      <div class="card">
      <div class="card-header bg-dark text-center">
        <a class="card-link " data-toggle="collapse" href="#course_progress">
          Course Progress
        </a>
      </div>
      <div id="course_progress" class="collapse " data-parent="#accordion">
        <div class="card-body">

   <div class="container">
   <p style="font-size:.868em"><kbd>Just 36% and Become Artist</kbd></p>
  <div class="card">
    <div class="card-header" style="background-color:white;"><div class="progress-bar"
    style="width:64%" >64%</div></div>
  </div>
</div>

<br /><br />
<div style="text-align:center;">
 <a href="/profile"> <button type="button" class="btn btn-success classroom_btn" >Go To My Profile </button> </a>
</div>
      <!-- video -->


        </div>
      </div>
    </div>





    <div class="card">
      <div class="card-header bg-dark">
        <a class="card-link" data-toggle="collapse" href="#collapseOne">
          Course Intro
        </a>
      </div>
      <div id="collapseOne" class="collapse show" data-parent="#accordion">
        <div class="card-body">
        <!-- video -->
<video width="100%" controls>
  <source src="mov_bbb.mp4" type="video/mp4">
  <source src="mov_bbb.ogg" type="video/ogg">
  Your browser does not support HTML video.
</video>

<br /><br />
<div style="text-align:center;">
 <button type="button" class="btn btn-success classroom_btn" >View Full Lesson</button>
</div>
      <!-- video -->


        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header bg-dark">
        <a class="collapsed card-link" data-toggle="collapse" href="#lesson1">

        <span>Lesson 1 </span>

      </a>
      <span class="play_list_span" title="Vote"><i class="fa fa-heart" style="font-size:26px;"></i></span>
      </div>
      <div id="lesson1" class="collapse" data-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          <br><br>
          <button  type="button" class="btn classroom_btn" >View Full Lesson</button>

        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header bg-dark">
        <a class="collapsed card-link" data-toggle="collapse" href="#lesson2">
          Lesson 2
        </a>
        <span class="play_list_span" title="Vote"><i class="fa fa-heart" style="font-size:26px;"></i></span>
      </div>
      <div id="lesson2" class="collapse" data-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

          <br><br>
          <button  type="button" class="btn classroom_btn" >View Full Lesson</button>
        </div>
      </div>
    </div>

        <div class="card">
      <div class="card-header bg-dark">
        <a class="collapsed card-link" data-toggle="collapse" href="#lesson3">
          Lesson 3

        </a>
        <span class="play_list_span" title="Vote"><i class="fa fa-heart" style="font-size:26px;"></i></span>
      </div>
      <div id="lesson3" class="collapse" data-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          <br><br>
          <button  type="button" class="btn classroom_btn" >View Full Lesson</button>
        </div>
      </div>
    </div>

        <div class="card">
      <div class="card-header bg-dark">
        <a class="collapsed card-link" data-toggle="collapse" href="#lesson4">
          Lesson 4

        </a>
        <span class="play_list_span" title="Vote"><i class="fa fa-heart" style="font-size:26px;"></i></span>
      </div>
      <div id="lesson4" class="collapse" data-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          <br><br>
          <button  type="button" class="btn classroom_btn" >View Full Lesson</button>
        </div>
      </div>
    </div>

        <div class="card">
      <div class="card-header bg-dark">
        <a class="collapsed card-link" data-toggle="collapse" href="#lesson5">
          Lesson 5
        </a>
        <span class="play_list_span" title="Vote"><i class="fa fa-heart" style="font-size:26px;"></i></span>
      </div>
      <div id="lesson5" class="collapse" data-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          <br><br>
          <button  type="button" class="btn classroom_btn" >View Full Lesson</button>
        </div>
      </div>
    </div>

        <div class="card">
      <div class="card-header bg-dark">
        <a class="collapsed card-link" data-toggle="collapse" href="#lesson6">
         Lesson 6
        </a>
        <span class="play_list_span" title="Vote"><i class="fa fa-heart" style="font-size:26px;"></i></span>
      </div>
      <div id="lesson6" class="collapse" data-parent="#accordion">
        <div class="card-body">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          <br><br>
          <button  type="button" class="btn classroom_btn" >View Full Lesson</button>
        </div>
      </div>
    </div>


  </div>
</div>

    <!-- information end -->
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>TITLE HEADING</h2>
      <h5>Title description, Dec 7, 2017</h5>
      <br />
      <div class="fakeimg">
      <!-- video -->
<video width="100%" controls>
  <source src="mov_bbb.mp4" type="video/mp4">
  <source src="mov_bbb.ogg" type="video/ogg">
  Your browser does not support HTML video.
</video></div>

<div>
      <p>Some text..</p>
      <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
      </div>
      <br />
      <br /><br />
      <h2>TITLE HEADING</h2>
      <h5>Title description, Sep 2, 2017</h5>
      <div class="fakeimg"><video style="border:2px solid #ff6699;" width="100%"  controls>
  <source src="mov_bbb.mp4" type="video/mp4">
  <source src="mov_bbb.ogg" type="video/ogg">
  Your browser does not support HTML video.
</video>

</div>
      <p>Lesson one..</p>
      <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
    </div>
  </div>
</div>

<div class="jumbotron text-center bg_foot" style="margin-bottom:0">
  <p>Footer</p>
</div>

<div>
</body>
</html>
