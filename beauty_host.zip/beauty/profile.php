<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.php');
	exit;
}

include('db.php');

// get loged user info from database
$stmt = $con->prepare('SELECT password, email, paid, image FROM accounts WHERE id = ?');
// In this case we can use the account ID to get the account info.
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($password, $email, $paid, $image);
$stmt->fetch();
$stmt->close();

// Convert $paid from number to String
if ($paid === 1) {
	$converted_paid = 'Yes';
} else {
	$converted_paid = 'Nope';
}

?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Profile Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

  <link href="static/style.css" rel="stylesheet" type="text/css">



	  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

	  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
	  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">

	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	  <link href="static/style.css" rel="stylesheet" type="text/css">

	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


		<style>
		.navtop {
		background-color: #2f3947;
		height: 60px;
		width: 100%;
		border: 0;
	}
	.navtop div {
		display: flex;
		margin: 0 auto;
		width: 1000px;
		height: 100%;
	}
	.navtop div h1, .navtop div a {
		display: inline-flex;
		align-items: center;
	}
	.navtop div h1 {
		flex: 1;
		font-size: 24px;
		padding: 0;
		margin: 0;
		color: #eaebed;
		font-weight: normal;
	}
	.navtop div a {
		padding: 0 20px;
		text-decoration: none;
		color: #c1c4c8;
		font-weight: bold;
	}
	.navtop div a i {
		padding: 2px 8px 0 0;
	}
	.navtop div a:hover {
		color: #eaebed;
	}
	body.loggedin {
		background-color: #f3f4f7;
	}
	.content {
		width: 1000px;
		margin: 0 auto;
	}
	.content h2 {
		margin: 0;
		padding: 25px 0;
		font-size: 22px;
		border-bottom: 1px solid #e0e0e3;
		color: #4a536e;
	}
	.content > p, .content > div {
		box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.1);
		margin: 25px 0;
		padding: 25px;
		background-color: #fff;
	}
	.content > p table td, .content > div table td {
		padding: 5px;
	}
	.content > p table td:first-child, .content > div table td:first-child {
		font-weight: bold;
		color: #4a536e;
		padding-right: 15px;
	}
	.content > div p {
		padding: 5px;
		margin: 0 0 10px 0;
	}
		</style>
	</head>
	<body class="loggedin">


				<nav class="navbar navbar-expand-md bg-sucess navbar-dark fixed-top" id="mytopnav">
				  <a class="navbar-brand" href="index.php"><img src="static/logo_transparent.png" width="50" height="50" alt="beauty demy logo"></a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				    <span class="navbar-toggler-icon"></span>
				  </button>
				  <div class="collapse navbar-collapse" id="collapsibleNavbar">
				    <ul class="navbar-nav ">
							<?php if ($paid === 1) { ?>
				      <li class="nav-item">
				        <a class="nav-link" data-nav='classroom' href="classroom.php" title="Go To ClassRoom Page">MY CLASSROOM</a>
				      </li>
					  	<?php } ?>
				      <li class="nav-item">
				        <a class="nav-link" data-nav='beauty_comunity' href="#beauty_comunity" title="Beauty Community for Premium Beauty Demy Memeber">BEAUTY Community</a>
				      </li>
				       <li class="nav-item">
				        <a class="nav-link" href="profile.php" data-nav='contact' title="Go To Your Profile Page" ><i class="fas fa-user-circle"></i>Profile</a>
				      </li>
							<li class="nav-item">
							 <a class="nav-link" href="logout.php" data-nav='contact' title="Go To Your Profile Page" ><i class="fas fa-sign-out-alt"></i>Logout</a>
						 </li>
				    </ul>
				  </div>
				</nav>


		<div class="content" style="margin-top:100px;">
			<h2>Profile Page</h2>
			<div class="container">
				<div class="text-center">
				<img src="<?=$image?>" width="200" height="200" alt="<?=$_SESSION['name']?>">
				<br /><br />
				<button class="btn btn-info">Edit Profile</button>
			</div>
			<br /><br />
			<h4>Course Progress</h4>
			<div class="progress" style="width:30%;">
			<div class="progress-bar" style="width:70%">70%</div>
			</div>
				<br />

				<table>
					<tr>
						<td>Username:</td>
						<td><?=$_SESSION['name']?></td>
					</tr>
					<tr>
						<td>Password:</td>
						<td><?=$password?></td>
					</tr>
					<tr>
						<td>Email:</td>
						<td><?=$email?></td>
					</tr>
					<tr>
						<td>Premuium:</td>
						<td><?=$converted_paid?></td>
					</tr>
				</table>
			</div>
		</div>
	</body>
</html>
